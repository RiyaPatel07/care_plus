import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:doctor/screens/login_screen.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  bool passToggle = true;
  final _formKey = GlobalKey<FormState>();
  final dbRef = FirebaseFirestore.instance.collection('Users');
  final ValueNotifier<bool> obsecurePassword = ValueNotifier<bool>(true);

  final userNameController = TextEditingController();
  final passwordController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();

  String name = "";
  String email = "";
  String password = "";
  var phone = "";

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              SizedBox(height: 10),
              Padding(
                padding: EdgeInsets.all(20),
                child: Image.asset("images/doctor 2.jfif"),
              ),
              SizedBox(height: 15),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                child: TextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  autofocus: false,
                  controller: userNameController,
                  decoration: InputDecoration(
                    labelText: "Full Name",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Fill the name';
                    }
                    return null;
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                child: TextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  autofocus: false,
                  controller: emailController,
                  decoration: InputDecoration(
                    labelText: "Email Address",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.email),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'No user for this email';
                    } else if (!EmailValidator.validate(value)) {
                      return ' Enter Valid Email';
                    }
                    return null;
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                child: TextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  autofocus: false,
                  controller: phoneController,
                  decoration: InputDecoration(
                    labelText: "Phone Number",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.phone),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Fill the name';
                    }
                    return null;
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                child:  ValueListenableBuilder(valueListenable: obsecurePassword,
                  builder: (context, value, child) {
                    return TextFormField(
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      controller: passwordController,
                      obscureText: obsecurePassword.value,
                      obscuringCharacter: "*",
                      decoration: InputDecoration(
                        labelText: 'Create Password',
                        hintText: 'Create your password',
                        prefixIcon: const Icon(Icons.lock_open_outlined,),
                        border: const OutlineInputBorder(),
                        suffixIcon: InkWell(onTap: () {
                          obsecurePassword.value = !obsecurePassword.value;
                        }, child: Icon(obsecurePassword.value ? Icons
                            .visibility_off_outlined : Icons.visibility,),),),
                      validator: (value) {

                        if (value == null || value.isEmpty) {
                          return 'Enter your password';
                        }
                        return null;
                      },);
                  },),

              ),



              SizedBox(height: 10),
              MaterialButton(
                color: Color(0xFF7165D6),
                onPressed: () { if (_formKey.currentState!.validate()) {
                  setState(() {
                    email = emailController.text;
                    password = passwordController.text;
                    phone = phoneController.text;
                    name = userNameController.text;
                  });
                  UserSignUp();
                } },
                child: Text(
                  "Create Account",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Already have any account?",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.black54,
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => LoginScreen(),
                          ));
                    },
                    child: Text(
                      "Log In",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF7165D6),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  UserSignUp() async {
    setState(() {
      passToggle = true;
    });
    final signInMethods = await FirebaseAuth.instance
        .fetchSignInMethodsForEmail(email);
    if (signInMethods.isNotEmpty) {
      setState(() {
        passToggle = false;
      });
      return;
    }
    try {
      final authResult = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password);
      String userId = authResult.user!.uid.toString();

      dbRef.doc(userId).set({
        'uid': userId,
        'u_name': name.toString(),
        'email': authResult.user!.email.toString(),
        'number': '',
      }).then((value) {}).onError((error, stackTrace) {

      });
      Navigator.push(context,
        MaterialPageRoute(builder: (context) => LoginScreen(),),);
      setState(() {
        passToggle = false;
      },);

    } catch (error) {
      if (kDebugMode) {
        print("Error ${error.toString()}");
      }
    }

  }


}
