package com.example.doctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
